const MainPage = () => <div>메인 페이지입니다.</div>;
export default MainPage;